1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1kja2ozxjvzqy.js","/_next/static/chunks/14mrh2-p_w84d.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/1kja2ozxjvzqy.js","/_next/static/chunks/14mrh2-p_w84d.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/1kja2ozxjvzqy.js","/_next/static/chunks/14mrh2-p_w84d.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Taqseet Manager"}],["$","meta","1",{"name":"description","content":"Motorcycle installment and point of sale manager."}],["$","link","2",{"rel":"manifest","href":"/manifest.json"}],["$","link","3",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","4",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"e-EFoGfqBWWN_1nuMKqmB"}
